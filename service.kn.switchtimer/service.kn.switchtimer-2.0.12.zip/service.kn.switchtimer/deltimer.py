#!/usr/bin/python
# -*- coding: utf-8 -*-

import handler

if __name__ ==  '__main__':

    handler.notifyLog('Parameter handler called: delete timerlist')
    handler.clearTimerProperties()
