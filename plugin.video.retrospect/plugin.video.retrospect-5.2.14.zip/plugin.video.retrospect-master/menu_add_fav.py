# SPDX-License-Identifier: CC-BY-NC-SA-4.0

from resources.lib import menu

with menu.Menu("Add Favourite") as m:
    m.add_favourite()
