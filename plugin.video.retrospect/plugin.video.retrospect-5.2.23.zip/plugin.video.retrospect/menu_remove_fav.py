# SPDX-License-Identifier: GPL-3.0-or-later

from resources.lib import menu

with menu.Menu("Remove Favourite") as m:
    m.remove_favourite()
